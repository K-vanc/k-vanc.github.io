After downloading and inserting the file to siteconfig folder,<br>
you can create your own channel list for nettv.com.mx based on zip/postal code you want.<br>
All you need to do is, going into "Channel Generator" tab<br>
Choosing siteconfig file from loader<br>
And typing your zip/postal code into "User Key" box such as 01000 etc.<br>
![image](https://github.com/K-vanc/Tempest-EPG-Generator/assets/97025515/eab54bb0-6975-4f12-bd5f-579444f31e7d)
<br>And all channels linked to entered postal code will be listed in created channel.xml file<br>
![image](https://github.com/K-vanc/Tempest-EPG-Generator/assets/97025515/cc2ac552-0c5f-4b6b-85de-3729a25a729b)