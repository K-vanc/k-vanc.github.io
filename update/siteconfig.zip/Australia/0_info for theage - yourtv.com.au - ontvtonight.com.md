For channel creation of "tvguide.theage.com.au" , "yourtv.com.au" & "ontvtonight.com", user should input desired region code to User Key box.<br>
![image](https://user-images.githubusercontent.com/97025515/173569151-94f08a99-523c-43e2-ab13-9a1495851c5a.png)
<br>If channel creation started without User Key<br>
Tempest will auto create "theage_location_codes" or "yourtv_location_codes" file into the "/tempest_config/site_config" folder for info
