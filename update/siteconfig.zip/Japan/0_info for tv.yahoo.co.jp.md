For channel creation of "tv.yahoo.co.jp" , user should input desired region code to User Key box.<br>
![image](https://user-images.githubusercontent.com/97025515/235286665-c98967cb-5132-4ecc-b4e1-8346b22f2222.png)
<br>If channel creation started without User Key<br>
Tempest will auto create "tv.yahoo.co.jp_codes.txt" file into the "/tempest_config/site_config" folder for info
