For channel creation of "tvguide.com[Multi]" , user should input desired country/city code to User Key box.<br>
![image](https://user-images.githubusercontent.com/97025515/158015124-db3ea120-5a6d-4213-8f60-0ee4e3924820.png)
<br>
![image](https://user-images.githubusercontent.com/97025515/158014888-564bb7f2-dadd-462c-8c24-f5d1462ab1ae.png)
<br><br>If channel creation started without User Key<br>
Tempest will auto create "tvguide_country_codes.txt" file into "/tempest_config/site_config/" folder for info
