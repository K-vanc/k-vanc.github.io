After downloading and inserting the file to siteconfig folder,<br>
you can create your own channel list for ontvtonight, o.canada.com, thestar.com and tvlisting.gracenote based on zip/postal code you want.<br>
All you need to do is, going into "Channel Generator" tab<br>
Choosing siteconfig file from loader<br>
And typing your zip/postal code into "User Key" box such as M5G1P5 etc.<br>
![image](https://user-images.githubusercontent.com/97025515/174945060-98b9261e-f3b9-4f8b-bdb4-71cbb2a4d03c.png)
<br>And all channels linked to entered postal code will be listed in created channel.xml file<br>
![image](https://user-images.githubusercontent.com/97025515/174944987-30d91523-c07d-4ebe-aa3f-06d2b3c12774.png)
