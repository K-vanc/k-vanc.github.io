For channel creation of "tvpassport[CA]" , user should input desired region code to User Key box.<br>
![image](https://user-images.githubusercontent.com/97025515/153712567-a7c22b31-8bbd-442b-9eea-bbf5c72de87b.png)
<br>If channel creation started without User Key<br>
Tempest will auto create "tvpassport_canada_codes" file into the "/tempest_config/site_config" folder for info
