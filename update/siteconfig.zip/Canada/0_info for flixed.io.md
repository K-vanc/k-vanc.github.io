For channel creation of "flixed.io" , user should input desired region code to User Key box.<br>
![image](https://user-images.githubusercontent.com/97025515/153706813-014a18e3-289f-4051-a2b1-7d7c4671b9ea.png)
<br>If channel creation started without User Key<br>
Tempest will auto create "flixed_io_canada_codes.txt" file into the "/tempest_config/site_config" folder for info
